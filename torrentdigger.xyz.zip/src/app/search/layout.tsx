import Navbar from '@/components/core/Navbar'
import { Suspense } from 'react'

export default function SearchLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <div>
      <Navbar />
      <main>
        <Suspense fallback={null}>{children}</Suspense>
      </main>
    </div>
  )
}
