1:"$Sreact.fragment"
2:I[3964,["830","static/chunks/830-f4c900924edee883.js","177","static/chunks/app/layout-445fc9efdb014a40.js"],"TRPCReactProvider"]
3:I[7555,[],""]
4:I[1295,[],""]
5:I[6671,["830","static/chunks/830-f4c900924edee883.js","177","static/chunks/app/layout-445fc9efdb014a40.js"],"Toaster"]
6:I[894,[],"ClientPageRoot"]
7:I[760,["598","static/chunks/598-0939d2056ed58d8d.js","974","static/chunks/app/page-290401b8218d4a7c.js"],"default"]
a:I[9665,[],"OutletBoundary"]
d:I[9665,[],"ViewportBoundary"]
f:I[9665,[],"MetadataBoundary"]
11:I[6614,[],""]
:HL["/_next/static/media/01af0fc7b4278e65-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/06ef518b975660c0.css","style"]
0:{"P":null,"b":"Pb_X-fYiVjjy8O_ahtPIN","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/06ef518b975660c0.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"__className_5398f7","children":["$","body",null,{"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L5",null,{"position":"bottom-right"}]]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L6",null,{"Component":"$7","searchParams":{},"params":{},"promises":["$@8","$@9"]}],"$undefined",null,["$","$La",null,{"children":["$Lb","$Lc",null]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,["$","$1","r2BTVdhVlVbMKfO5xZXof",{"children":[["$","$Ld",null,{"children":"$Le"}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],["$","$Lf",null,{"children":"$L10"}]]}],false]],"m":"$undefined","G":["$11","$undefined"],"s":false,"S":true}
8:{}
9:{}
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
b:null
c:null
10:[["$","title","0",{"children":"Torrent Digger | Search Torrents Easily"}],["$","meta","1",{"name":"description","content":"Torrent Digger is a powerful torrent search engine that helps you find and download torrents quickly and easily."}],["$","meta","2",{"name":"author","content":"Torrent Digger"}],["$","meta","3",{"name":"keywords","content":"torrent,torrents,torrent search,torrent magnet,torrent download"}],["$","meta","4",{"name":"creator","content":"Torrent Digger"}],["$","meta","5",{"name":"publisher","content":"Torrent Digger"}]]
